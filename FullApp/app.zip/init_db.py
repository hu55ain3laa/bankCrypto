import os
from typing import Optional
from sqlmodel import SQLModel, Field, create_engine, Session, select
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import uuid
import bcrypt
import base64
from datetime import datetime
import streamlit as st

# SQLModel classes
class User(SQLModel, table=True):
    __table_args__ = {'extend_existing': True}
    id: Optional[str] = Field(default=None, primary_key=True)
    username: str = Field(unique=True, index=True)
    hashed_password: str
    iv: str
    balance: str
    created_at: Optional[str] = Field(default=None)

class Transaction(SQLModel, table=True):
    __table_args__ = {'extend_existing': True}
    id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    sender_id: str = Field(foreign_key="user.id")
    receiver_id: str = Field(foreign_key="user.id")
    amount: str
    encrypted_sender: str
    encrypted_receiver: str
    timestamp: Optional[str] = Field(default=None)

# Database initialization
engine = create_engine("sqlite:///bank.db")

def get_encryption_key():
    key = st.secrets["encryption_key"].encode()
    key_length = len(key)
    if key_length == 16 or key_length == 24 or key_length == 32:
        return key
    else:
        raise ValueError(f"Invalid key size: {key_length}. AES key must be 16, 24, or 32 bytes.")

def encrypt_data(data: str, iv: bytes) -> str:
    cipher = Cipher(
        algorithms.AES(get_encryption_key()),
        modes.CBC(iv),
        backend=default_backend()
    )
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data.encode()) + padder.finalize()
    encrypted = encryptor.update(padded_data) + encryptor.finalize()
    return base64.b64encode(encrypted).decode()

def create_db_and_tables():
    try:
        SQLModel.metadata.create_all(engine)
        return True
    except Exception as e:
        print(f"Error creating tables: {str(e)}")
        return False

def seed_initial_data():
    session = Session(engine)
    try:
        # Check if users already exist
        alice = session.exec(select(User).where(User.username == "alice")).first()
        bob = session.exec(select(User).where(User.username == "bob")).first()

        if not alice:
            # Create Alice's account
            iv = os.urandom(16)
            encrypted_balance = encrypt_data("1000", iv)

            alice = User(
                id=str(uuid.uuid4()),
                username="alice",
                hashed_password=bcrypt.hashpw("password123".encode(), bcrypt.gensalt()).decode(),
                iv=base64.b64encode(iv).decode(),
                balance=encrypted_balance,
                created_at=datetime.now().isoformat()
            )
            session.add(alice)

        if not bob:
            # Create Bob's account
            iv = os.urandom(16)
            encrypted_balance = encrypt_data("1000", iv)

            bob = User(
                id=str(uuid.uuid4()),
                username="bob",
                hashed_password=bcrypt.hashpw("password123".encode(), bcrypt.gensalt()).decode(),
                iv=base64.b64encode(iv).decode(),
                balance=encrypted_balance,
                created_at=datetime.now().isoformat()
            )
            session.add(bob)

        session.commit()
        print("Initial data seeded successfully")
        return True
    except Exception as e:
        session.rollback()
        print(f"Error seeding initial data: {str(e)}")
        return False
    finally:
        session.close()

if __name__ == "__main__":
    if create_db_and_tables():
        print("Database tables created successfully")
        if seed_initial_data():
            print("Initial data seeded successfully")
        else:
            print("Failed to seed initial data")
    else:
        print("Failed to create database tables")